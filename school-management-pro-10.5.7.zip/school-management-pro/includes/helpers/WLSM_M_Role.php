<?php
defined( 'ABSPATH' ) || die();

require_once WLSM_PLUGIN_DIR_PATH . 'includes/helpers/WLSM_Config.php';

class WLSM_M_Role {
	private static $admin    = 'admin';
	private static $employee = 'employee';

	public static function get_user_info($user_id = '') {
		if ($data = wp_cache_get('wlsm_user_info')) {
			return $data;
		}

		global $wpdb;

		if (!$user_id) {
			$user_id = get_current_user_id();
		}

		$current_school_id = get_user_meta($user_id, 'wlsm_school_id', true);

		$schools = array();

		$staff_in_school = false;

		$staff = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT sf.role, a.role_id, sf.permissions, a.ID as admin_id, sf.school_id, s.label as school_name, a.section_id, s.is_active FROM ' . WLSM_STAFF . ' as sf
				JOIN ' . WLSM_SCHOOLS . ' as s ON s.ID = sf.school_id
				LEFT OUTER JOIN ' . WLSM_ADMINS . ' as a ON a.staff_id = sf.ID
				WHERE sf.user_id = %d',
				$user_id
			)
		);

		if (count($staff)) {
			foreach ($staff as $user) {
				if ($user->school_id === $current_school_id) {
					$staff_in_school = true;

					$school_id   = $user->school_id;
					$role        = $user->role;
					$role_id     = $user->role_id;
					$admin_id    = $user->admin_id;
					$permissions = $user->permissions ? unserialize($user->permissions) : array();
					$school_name = $user->school_name;
					$section_id  = $user->section_id;
					$is_active   = $user->is_active;

					// Fetch permissions from WLSM_ROLES if role_id exists
					if ($role_id) {
						$role_permissions = $wpdb->get_var(
							$wpdb->prepare(
								'SELECT permissions FROM ' . WLSM_ROLES . ' WHERE ID = %d',
								$role_id
							)
						);
						if ($role_permissions) {
							$permissions = unserialize($role_permissions);
						}
					}
				}

				array_push(
					$schools,
					array(
						'id'   => $user->school_id,
						'name' => $user->school_name,
					)
				);
			}
		}

		$data = array(
			'schools_assigned' => $schools,
		);

		if ($staff_in_school) {
			if (self::get_admin_key() == $role) {
				$permissions = array_keys(self::get_permissions());
			}

			$data['current_school'] = array(
				'id'          => $school_id,
				'role'        => $role,
				'role_id'     => $role_id,
				'admin_id'    => $admin_id,
				'permissions' => $permissions,
				'name'        => $school_name,
				'is_active'   => $is_active,
				'section_id'  => $section_id,
			);
		} else {
			$data['current_school'] = false;

			if (1 === count($staff)) {
				update_user_meta($user_id, 'wlsm_school_id', $staff[0]->school_id);
			}
		}

		wp_cache_add('wlsm_user_info', $data);

		return $data;
	}

	// Restrict staff to section.
	public static function restrict_to_section( $current_school ) {
		$role       = $current_school['role'];
		$section_id = $current_school['section_id'];

		$restrict_to_section = false;
		if ( self::get_employee_key() === $role ) {
			$restrict_to_section = $section_id;
		}

		return $restrict_to_section;
	}

	// Get if user is staff.
	public static function get_user_admin( $school_id, $user_id = '' ) {
		global $wpdb;

		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		$admin = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT a.ID FROM ' . WLSM_ADMINS . ' as a
			JOIN ' . WLSM_STAFF . ' as sf ON sf.ID = a.staff_id
			WHERE sf.school_id = %d AND sf.user_id = %d',
				$school_id,
				$user_id
			)
		);

		return $admin;
	}

	public static function get_roles() {
		return array(
			self::$admin    => esc_html__( 'Admin', 'school-management' ),
			self::$employee => esc_html__( 'Staff', 'school-management' ),
		);
	}

	public static function get_staff_roles( $school_id ) {
		global $wpdb;

		$staff_roles = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT r.ID, r.name FROM ' . WLSM_ROLES . ' as r
		WHERE r.school_id = %d',
				$school_id
			),
			OBJECT_K
		);

		return $staff_roles;
	}

	public static function get_role_text( $role ) {
		if ( array_key_exists( $role, self::get_roles() ) ) {
			return self::get_roles()[ $role ];
		}

		return '';
	}

	public static function get_admin_key() {
		return self::$admin;
	}

	public static function get_employee_key() {
		return self::$employee;
	}

	public static function get_permissions() {
		return array(
			'add_inquiries'           => esc_html__( 'Add Inquiries', 'school-management' ),
			'view_inquiries'          => esc_html__( 'View Inquiries', 'school-management' ),
			'edit_inquiries'          => esc_html__( 'Edit Inquiries', 'school-management' ),
			'delete_inquiries'        => esc_html__( 'Delete Inquiries', 'school-management' ),
			'manage_admissions'       => esc_html__( 'Manage Admissions', 'school-management' ),
			'view_students'           => esc_html__( 'View Students', 'school-management' ),
			'edit_students'           => esc_html__( 'Edit Students', 'school-management' ),
			'delete_students'         => esc_html__( 'Delete Students', 'school-management' ),
			'manage_promote'          => esc_html__( 'Student Promotion', 'school-management' ),
			'manage_admins'           => esc_html__( 'Add/Remove Admins', 'school-management' ),
			'manage_employees'        => esc_html__( 'Add/Remove Staff', 'school-management' ),
			'manage_roles'            => esc_html__( 'Manage Roles', 'school-management' ),
			'manage_transfer_student' => esc_html__( 'Transfer Student', 'school-management' ),
			'add_certificates'        => esc_html__( 'Add Certificates', 'school-management' ),
			'view_certificates'       => esc_html__( 'View Certificates', 'school-management' ),
			'edit_certificates'       => esc_html__( 'Edit Certificates', 'school-management' ),
			'issue_certificates'      => esc_html__( 'Issue Certificates', 'school-management' ),
			'delete_certificates'     => esc_html__( 'Delete Certificates', 'school-management' ),
			'manage_classes'          => esc_html__( 'Manage Classes & Sections', 'school-management' ),
			'assigned_class'          => esc_html__( 'Only Manage Assigned Class', 'school-management' ),
			'delete_sections'         => esc_html__( 'Delete Class Sections', 'school-management' ),
			'add_subjects'            => esc_html__( 'Add Subjects', 'school-management' ),
			'view_subjects'           => esc_html__( 'View Subjects', 'school-management' ),
			'edit_subjects'           => esc_html__( 'Edit Subjects', 'school-management' ),
			'delete_subjects'         => esc_html__( 'Delete Subjects', 'school-management' ),
			'assigned_subjects'       => esc_html__( 'Manage Assigned Subjects', 'school-management' ),
			'add_timetable'           => esc_html__( 'Add Timetable', 'school-management' ),
			'view_timetable'          => esc_html__( 'View Timetable', 'school-management' ),
			'edit_timetable'          => esc_html__( 'Edit Timetable', 'school-management' ),
			'delete_timetable'        => esc_html__( 'Delete Timetable', 'school-management' ),
			'add_attendance'          => esc_html__( 'Add Student Attendance', 'school-management' ),
			'view_attendance'         => esc_html__( 'View Student Attendance', 'school-management' ),
			'edit_attendance'         => esc_html__( 'Edit Student Attendance', 'school-management' ),
			'manage_staff_attendance' => esc_html__( 'Manage Staff Attendance', 'school-management' ),
			'take_staff_attendance'   => esc_html__( 'Take Staff Attendance', 'school-management' ),
			'view_staff_attendance'   => esc_html__( 'View Staff Attendance', 'school-management' ),
			'add_student_leaves'      => esc_html__( 'Add Student Leaves', 'school-management' ),
			'view_student_leaves'     => esc_html__( 'View Student Leaves', 'school-management' ),
			'edit_student_leaves'     => esc_html__( 'Edit Student Leaves', 'school-management' ),
			'delete_student_leaves'   => esc_html__( 'Delete Student Leaves', 'school-management' ),
			'view_staff_leaves'       => esc_html__( 'View Staff Leaves', 'school-management' ),
			'edit_staff_leaves'       => esc_html__( 'Edit Staff Leaves', 'school-management' ),
			'delete_staff_leaves'     => esc_html__( 'Delete Staff Leaves', 'school-management' ),
			'view_study_materials'    => esc_html__( 'View Study Materials', 'school-management' ),
			'edit_study_materials'    => esc_html__( 'Edit Study Materials', 'school-management' ),
			'delete_study_materials'  => esc_html__( 'Delete Study Materials', 'school-management' ),
			'view_homework'           => esc_html__( 'View Homework', 'school-management' ),
			'edit_homework'           => esc_html__( 'Edit Homework', 'school-management' ),
			'delete_homework'         => esc_html__( 'Delete Homework', 'school-management' ),
			'add_live_classes'        => esc_html__( 'Add Live Classes', 'school-management' ),
			'view_live_classes'       => esc_html__( 'View Live Classes', 'school-management' ),
			'edit_live_classes'       => esc_html__( 'Edit Live Classes', 'school-management' ),
			'delete_live_classes'     => esc_html__( 'Delete Live Classes', 'school-management' ),
			'add_library'             => esc_html__( 'Add Books', 'school-management' ),
			'view_library'            => esc_html__( 'View Library', 'school-management' ),
			'edit_library'            => esc_html__( 'Edit Library', 'school-management' ),
			'delete_library'          => esc_html__( 'Delete Library', 'school-management' ),
			  // 'manage_library'              => esc_html__( 'Manage Library', 'school-management' ),
			'issue_books'                 => esc_html__( 'Issue Books', 'school-management' ),
			'issue_library_card'          => esc_html__( 'Issue Library Card', 'school-management' ),
			'add_transport'               => esc_html__( 'Add Transport', 'school-management' ),
			'view_transport'              => esc_html__( 'View Transport', 'school-management' ),
			'edit_transport'              => esc_html__( 'Edit Transport', 'school-management' ),
			'delete_transport'            => esc_html__( 'Delete Transport', 'school-management' ),
			'add_notices'                 => esc_html__( 'Add Noticeboard', 'school-management' ),
			'view_notices'                => esc_html__( 'View Noticeboard', 'school-management' ),
			'edit_notices'                => esc_html__( 'Edit Noticeboard', 'school-management' ),
			'delete_notices'              => esc_html__( 'Delete Noticeboard', 'school-management' ),
			'add_events'                  => esc_html__( 'Add Events', 'school-management' ),
			'view_events'                 => esc_html__( 'View Events', 'school-management' ),
			'edit_events'                 => esc_html__( 'Edit Events', 'school-management' ),
			'delete_events'               => esc_html__( 'Delete Events', 'school-management' ),
			'add_exams'                   => esc_html__( 'Add Exams', 'school-management' ),
			'view_exams'                  => esc_html__( 'View Exams', 'school-management' ),
			'edit_exams'                  => esc_html__( 'Edit Exams', 'school-management' ),
			'delete_exams'                => esc_html__( 'Delete Exams', 'school-management' ),
			'add_expenses'                => esc_html__( 'Add Expenses', 'school-management' ),
			'view_expenses'               => esc_html__( 'View Expenses', 'school-management' ),
			'edit_expenses'               => esc_html__( 'Edit Expenses', 'school-management' ),
			'delete_expenses'             => esc_html__( 'Delete Expenses', 'school-management' ),
			'add_income'                  => esc_html__( 'Add Donation', 'school-management' ),
			'view_income'                 => esc_html__( 'View Donation', 'school-management' ),
			'edit_income'                 => esc_html__( 'Edit Donation', 'school-management' ),
			'delete_income'               => esc_html__( 'Delete Donation', 'school-management' ),
			'add_invoices'                => esc_html__( 'Add Invoices', 'school-management' ),
			'view_invoices'               => esc_html__( 'View Invoices', 'school-management' ),
			'delete_invoices'             => esc_html__( 'Delete Invoices', 'school-management' ),
			'edit_invoices'               => esc_html__( 'Edit Invoices', 'school-management' ),
			'delete_payments'             => esc_html__( 'Delete Payments', 'school-management' ),
			'stats_payments'              => esc_html__( 'View Stats - Payments', 'school-management' ),
			'stats_amount_fees_structure' => esc_html__( 'View Stats - Amount By Fees Structure', 'school-management' ),
			'stats_expense'               => esc_html__( 'View Stats - Expense', 'school-management' ),
			'stats_income'                => esc_html__( 'View Stats - Donation', 'school-management' ),
			'add_fees'                    => esc_html__( 'Add Fee Types', 'school-management' ),
			'view_fees'                   => esc_html__( 'View Fee Types', 'school-management' ),
			'edit_fees'                   => esc_html__( 'Edit Fee Types', 'school-management' ),
			'delete_fees'                 => esc_html__( 'Delete Fee Types', 'school-management' ),
			'send_notifications'          => esc_html__( 'Send Notifications', 'school-management' ),
			'manage_settings'             => esc_html__( 'Manage Settings', 'school-management' ),
			'manage_logs'                 => esc_html__( 'Manage Logs', 'school-management' ),
			'add_hostel'                  => esc_html__( 'Add Hostel', 'school-management' ),
			'view_hostel'                 => esc_html__( 'View Hostel', 'school-management' ),
			'edit_hostel'                 => esc_html__( 'Edit Hostel', 'school-management' ),
			'delete_hostel'               => esc_html__( 'Delete Hostel', 'school-management' ),
			'add_activities'              => esc_html__( 'Add Activities', 'school-management' ),
			'view_activities'             => esc_html__( 'View Activities', 'school-management' ),
			'edit_activities'             => esc_html__( 'Edit Activities', 'school-management' ),
			'delete_activities'           => esc_html__( 'Delete Activities', 'school-management' ),
			'add_lessons'                 => esc_html__( 'Add Lessons', 'school-management' ),
			'view_lessons'                => esc_html__( 'View Lessons', 'school-management' ),
			'edit_lessons'                => esc_html__( 'Edit Lessons', 'school-management' ),
			'delete_lessons'              => esc_html__( 'Delete Lessons', 'school-management' ),
			'add_tickets'                 => esc_html__( 'Add Tickets', 'school-management' ),
			'view_tickets'                => esc_html__( 'View Tickets', 'school-management' ),
			'edit_tickets'                => esc_html__( 'Edit Tickets', 'school-management' ),
			'delete_tickets'              => esc_html__( 'Delete Tickets', 'school-management' ),
			'assigned_tickets'            => esc_html__( 'View Only Assigned Tickets', 'school-management' ),


		);
	}

	public static function check_permission( $permissions_to_check, $user_permissions ) {
		return ! empty( array_intersect( $permissions_to_check, $user_permissions ) );
	}

	public static function get_role_permissions( $role, $permissions ) {
		$permissions_keys = array_keys( self::get_permissions() );

		if ( self::get_admin_key() == $role ) {
			$permissions = $permissions_keys;
		} else {
			if ( is_serialized( $permissions ) ) {
				$permissions = unserialize( $permissions );
			}
			return array_intersect( $permissions, $permissions_keys );
		}

		return $permissions;
	}

	public static function can( $permission ) {
		$user_info      = self::get_user_info();
		$current_school = $user_info['current_school'];


		if ( ! $current_school ) {
			return false;
		}

		$role = $current_school['role'];
		if ( in_array( $role, array_keys( self::get_roles() ) ) ) {
			$permissions = $current_school['permissions'];
			if ( ! is_array( $permission ) ) {
				$permission = array( $permission );
			}
			if ( self::check_permission( $permission, $permissions ) ) {
				$current_session = WLSM_Config::current_session();
				return array(
					'school'  => $current_school,
					'session' => $current_session,
				);
			}
		}

		return false;
	}

	public static function get_permission_text( $permission ) {
		if ( isset( self::get_permissions()[ $permission ] ) ) {
			return self::get_permissions()[ $permission ];
		}

		return '';
	}

	public static function get_admin_text() {
		return self::get_roles()[ self::$admin ];
	}

	public static function get_employee_text() {
		return self::get_roles()[ self::$employee ];
	}
}
