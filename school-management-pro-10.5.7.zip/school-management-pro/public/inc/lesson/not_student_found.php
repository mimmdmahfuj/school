<?php 
defined( 'ABSPATH' ) || die();
?>
<h2><?php esc_html_e( 'Please login with student Account!', 'school-management' ); ?></h2>