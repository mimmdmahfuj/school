<?php
defined('ABSPATH') || die();
require_once WLSM_PLUGIN_DIR_PATH . 'includes/helpers/staff/WLSM_M_tickets.php';

$action_for = 'st';
if (isset($change_action)) {
	$action_for = $set_action_for;
}

$student_id = isset($_GET['student_id']) ? absint($_GET['student_id']) : 0;
if ($student) {
	$school_id = $student->school_id;
	if (!$student_id) {
		$student_id = $student->ID;
	}
}

// Fetch student tickets with assigned staff details
$tickets = WLSM_M_Staff_Tickets::get_student_tickets($student_id);

// Fetch details of the selected ticket
$selected_ticket_id = isset($_GET['ticket_id']) ? absint($_GET['ticket_id']) : 0;
$selected_ticket = $selected_ticket_id ? WLSM_M_Staff_Tickets::fetch_ticket($selected_ticket_id) : null;
$ticket_history = $selected_ticket ? WLSM_M_Staff_Tickets::get_ticket_history($selected_ticket_id) : [];
?>

<div class="wlsm-content-area wlsm-section-ticket-history wlsm-student-ticket-history">
<div class="wlsm-d-flex wlsm-justify-content-between wlsm-align-items-center wlsm-mb-3">
    <div class="wlsm-st-main-title">
        <span>
            <?php esc_html_e('Support Tickets', 'school-management'); ?>
        </span>
    </div>
   	<a class="wlsm-navigation-link<?php if ( 'add_ticket' === $action ) { echo ' active'; } ?>" href="<?php echo esc_url( add_query_arg( array( 'action' => 'add_ticket', 'student_id' => $student->ID ), $current_page_url ) ); ?>"><?php esc_html_e( 'Add Ticket', 'school-management' ); ?></a>
</div>

    <div class="wlsm-st-ticket-history-section">
        <?php if (!empty($tickets)): ?>
            <div class="wlsm-table-section">
                <div class="table-responsive w-100 wlsm-w-100">
                    <table class="table table-bordered wlsm-student-ticket-history-table wlsm-w-100">
                        <thead>
                            <tr class="bg-primary text-white">
                                <th><?php esc_html_e('Title', 'school-management'); ?></th>
                                <th><?php esc_html_e('Description', 'school-management'); ?></th>
                                <th><?php esc_html_e('Status', 'school-management'); ?></th>
                                <th><?php esc_html_e('Priority', 'school-management'); ?></th>
                                <th><?php esc_html_e('Assigned To', 'school-management'); ?></th>
                                <th><?php esc_html_e('Created At', 'school-management'); ?></th>
                                <th class="text-center"><?php esc_html_e('Action', 'school-management'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tickets as $ticket): ?>
                                <?php
                                $staff = WLSM_M_Staff_General::fetch_staff_name($ticket->assigned_to);
                                $staff_name = $staff ? $staff->name : '';
                                ?>
                                <tr>
                                    <td><?php echo esc_html($ticket->title); ?></td>
                                    <td><?php echo wp_trim_words(esc_html($ticket->description), 10); ?></td>
                                    <td>
                                        <?php echo wp_kses_post(WLSM_M_Staff_Tickets::get_status_badge($ticket->status)); ?>
                                    </td>
                                    <td>
                                        <span class="wlsm-badge wlsm-badge-<?php echo esc_attr($ticket->priority === 'high' ? 'danger' : ($ticket->priority === 'medium' ? 'warning' : 'info')); ?>">
                                            <?php echo esc_html(ucfirst($ticket->priority)); ?>
                                        </span>
                                    </td>
                                    <td><?php echo esc_html($staff_name ?? '-'); ?></td>
                                    <td><?php echo esc_html(WLSM_Config::get_date_text($ticket->created_at)); ?></td>
                                    <td class="text-center">
                                        <a class="wlsm-<?php echo esc_attr($action_for); ?>-ticket wlsm-ml-1"
                                           data-ticket-id="<?php echo esc_attr($ticket->ID); ?>"
                                           data-student="<?php echo esc_attr($student_id); ?>"
                                           data-nonce="<?php echo esc_attr(wp_create_nonce($action_for . '-ticket-' . $ticket->ID)); ?>"
                                           data-message-title="<?php printf(
                                               /* translators: %s: ticket ID */
                                               esc_attr__('Ticket - %s', 'school-management'),
                                               esc_attr($ticket->ID)
                                           ); ?>"
                                           data-close="<?php echo esc_attr__('Close', 'school-management'); ?>"
                                           href="#">
                                            <?php esc_html_e('View', 'school-management'); ?>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php else: ?>
            <div class="wlsm-alert wlsm-alert-warning wlsm-font-bold">
                <span class="wlsm-icon wlsm-icon-red">&#33;</span>
                <?php esc_html_e('No tickets found.', 'school-management'); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
